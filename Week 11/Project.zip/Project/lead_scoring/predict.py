import joblib
import os
from .preprocess import transform_single_lead

MODEL_PATH = os.path.join("models", "pipeline.pkl")
COLUMNS_PATH = os.path.join("models", "training_columns.pkl")

_model = None
_columns = None


def score_to_label(score: float) -> str:
    if score < 0.30:
        return "Cold"
    elif score < 0.60:
        return "Warm"
    return "Hot"


def get_model():
    global _model
    if _model is None:
        _model = joblib.load(MODEL_PATH)
    return _model


def get_columns():
    global _columns
    if _columns is None:
        _columns = joblib.load(COLUMNS_PATH)
    return _columns


def score_lead(lead_dict: dict) -> dict:
    model = get_model()
    training_columns = get_columns()

    X = transform_single_lead(lead_dict, training_columns)

    score = float(model.predict_proba(X)[0][1])
    label = score_to_label(score)

    top_factors = []
    if lead_dict.get("referral_id"):
        top_factors.append("has_referral")
    if lead_dict.get("notes"):
        top_factors.append("has_notes")
    if lead_dict.get("phone"):
        top_factors.append("has_phone")

    return {
        "score": round(score, 2),
        "label": label,
        "top_factors": top_factors[:3]
    }