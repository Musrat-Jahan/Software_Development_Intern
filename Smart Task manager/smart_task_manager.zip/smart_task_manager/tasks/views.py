import csv
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.core.paginator import Paginator
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.contrib.auth import logout
from django.shortcuts import redirect

from .forms import ProfileForm, RegisterForm, TaskForm
from .models import Task


def home_redirect(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return redirect('login')


def register(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Account created. You can log in now.')
            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, 'registration/register.html', {'form': form})


@login_required
def profile(request):
    profile_obj = request.user.profile

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile_obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated.')
            return redirect('profile')
    else:
        form = ProfileForm(instance=profile_obj)

    return render(request, 'tasks/profile.html', {'form': form})


@login_required
def dashboard(request):
    today = timezone.localdate()
    qs = Task.objects.filter(owner=request.user)

    total = qs.count()
    completed = qs.filter(status=Task.Status.COMPLETED).count()
    pending = qs.exclude(status=Task.Status.COMPLETED).count()
    overdue = qs.filter(due_date__lt=today).exclude(status=Task.Status.COMPLETED).count()

    recent_tasks = qs.order_by('-updated_at')[:5]

    return render(
        request,
        'tasks/dashboard.html',
        {
            'total': total,
            'completed': completed,
            'pending': pending,
            'overdue': overdue,
            'recent_tasks': recent_tasks,
        },
    )


@login_required
def task_list(request):
    qs = Task.objects.filter(owner=request.user)

    # Filters (GET)
    status = request.GET.get('status', '').strip()
    priority = request.GET.get('priority', '').strip()
    q = request.GET.get('q', '').strip()

    if status:
        qs = qs.filter(status=status)
    if priority:
        qs = qs.filter(priority=priority)
    if q:
        qs = qs.filter(title__icontains=q)

    paginator = Paginator(qs, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(
        request,
        'tasks/task_list.html',
        {
            'page_obj': page_obj,
            'status': status,
            'priority': priority,
            'q': q,
            'status_choices': Task.Status.choices,
            'priority_choices': Task.Priority.choices,
        },
    )


@login_required
def task_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.owner = request.user
            task.save()
            messages.success(request, 'Task created.')
            return redirect('task_list')
    else:
        form = TaskForm()

    return render(request, 'tasks/task_form.html', {'form': form, 'mode': 'Create'})


@login_required
def task_update(request, pk):
    task = get_object_or_404(Task, pk=pk, owner=request.user)

    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            messages.success(request, 'Task updated.')
            return redirect('task_list')
    else:
        form = TaskForm(instance=task)

    return render(request, 'tasks/task_form.html', {'form': form, 'mode': 'Update'})


@login_required
def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk, owner=request.user)

    if request.method == 'POST':
        task.delete()
        messages.success(request, 'Task deleted.')
        return redirect('task_list')

    return render(request, 'tasks/task_confirm_delete.html', {'task': task})


@login_required
def task_complete(request, pk):
    task = get_object_or_404(Task, pk=pk, owner=request.user)
    task.status = Task.Status.COMPLETED
    task.save(update_fields=['status', 'updated_at'])
    messages.success(request, 'Task marked as completed.')

    next_url = request.GET.get('next') or 'task_list'
    return redirect(next_url)


@login_required
def export_tasks_csv(request):
    """Export the current user's tasks to CSV.

    Respects the same GET filters as the task list (status, priority, q).
    """
    qs = Task.objects.filter(owner=request.user)

    status = request.GET.get('status', '').strip()
    priority = request.GET.get('priority', '').strip()
    q = request.GET.get('q', '').strip()

    if status:
        qs = qs.filter(status=status)
    if priority:
        qs = qs.filter(priority=priority)
    if q:
        qs = qs.filter(title__icontains=q)

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="tasks.csv"'

    writer = csv.writer(response)
    writer.writerow(['Title', 'Description', 'Status', 'Priority', 'Due Date', 'Created At', 'Updated At'])

    for t in qs.order_by('due_date', '-created_at'):
        writer.writerow([
            t.title,
            t.description,
            t.get_status_display(),
            t.get_priority_display(),
            t.due_date,
            t.created_at,
            t.updated_at,
        ])

    return response


@login_required
def toggle_theme(request):
    current = request.session.get('theme', 'light')
    request.session['theme'] = 'dark' if current != 'dark' else 'light'
    next_url = request.GET.get('next') or request.META.get('HTTP_REFERER') or 'dashboard'
    return redirect(next_url)

def logout_view(request):
    logout(request)
    return redirect("login")