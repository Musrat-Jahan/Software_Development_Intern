# Smart Task Management System (Django)

## Features
- Multi-user authentication (register, login, logout)
- Profile model auto-created via signals (picture + bio)
- Task CRUD (Create, Update, Delete)
- Mark task as completed
- Dashboard counts (total, completed, pending, overdue)
- Filtering (status, priority) + search (title)
- Pagination (5 per page)
- Security: all task queries are filtered by `owner=request.user`

## Setup
```bash
python -m venv venv
# Windows: venv\Scripts\activate
# macOS/Linux: source venv/bin/activate

pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open: http://127.0.0.1:8000/

## Pages
- `/register/` create account
- `/login/` login
- `/dashboard/` dashboard
- `/tasks/` task list + filter/search + pagination
- `/profile/` update profile

