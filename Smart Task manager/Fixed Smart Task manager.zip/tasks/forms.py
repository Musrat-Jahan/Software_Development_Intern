from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Profile, Task


class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")


class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ("profile_picture", "bio")


class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ("title", "description", "status", "priority", "due_date")
        widgets = {
            "due_date": forms.DateInput(attrs={"type": "date"}),
        }