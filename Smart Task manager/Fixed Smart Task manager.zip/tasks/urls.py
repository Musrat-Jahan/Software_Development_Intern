from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),

    path("register/", views.register, name="register"),
    path("login/", auth_views.LoginView.as_view(template_name="auth/login.html"), name="login"),
    path("logout/", views.logout_view, name="logout"),

    path("tasks/create/", views.task_create, name="task_create"),
    path("tasks/", views.task_list, name="task_list"),
    path("tasks/<int:pk>/edit/", views.task_update, name="task_update"),
    path("tasks/<int:pk>/delete/", views.task_delete, name="task_delete"),
    path("tasks/<int:pk>/complete/", views.task_complete, name="task_complete"),

    path("export/", views.export_tasks_csv, name="export_tasks_csv"),
    path("toggle-theme/", views.toggle_theme, name="toggle_theme"),

    path("profile/", views.profile, name="profile"),
]