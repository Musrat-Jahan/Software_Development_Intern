from django.core.management.base import BaseCommand
from django.core.mail import send_mail
from django.utils import timezone

from tasks.models import Task


class Command(BaseCommand):
    help = "Send email reminders for overdue tasks."

    def add_arguments(self, parser):
        parser.add_argument(
            "--cooldown-hours",
            type=int,
            default=24,
            help="Minimum hours between reminders for the same task.",
        )

    def handle(self, *args, **options):
        cooldown_hours = options["cooldown_hours"]
        now = timezone.now()
        today = now.date()
        cooldown_time = now - timezone.timedelta(hours=cooldown_hours)

        overdue_tasks = (
            Task.objects.select_related("owner")
            .filter(due_date__lt=today)
            .exclude(status=Task.Status.COMPLETED)
        )

        sent_count = 0

        for task in overdue_tasks:
            owner = task.owner

            # Skip if user has no email
            if not owner.email:
                continue

            # Skip if reminder sent recently
            if task.reminder_sent_at and task.reminder_sent_at > cooldown_time:
                continue

            subject = f"Overdue Task Reminder: {task.title}"
            message = (
                f"Hi {owner.username},\n\n"
                f"Your task is overdue:\n"
                f"- Title: {task.title}\n"
                f"- Due date: {task.due_date}\n"
                f"- Priority: {task.priority}\n"
                f"- Status: {task.status}\n\n"
                f"Please log in and update it.\n"
            )

            send_mail(
                subject=subject,
                message=message,
                from_email=None,  # uses DEFAULT_FROM_EMAIL
                recipient_list=[owner.email],
                fail_silently=False,
            )

            task.reminder_sent_at = now
            task.reminder_count = task.reminder_count + 1
            task.save(update_fields=["reminder_sent_at", "reminder_count"])

            sent_count += 1

        self.stdout.write(self.style.SUCCESS(f"Reminders sent: {sent_count}"))