import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from predict import score_to_label


def test_score_to_label_cold():
    assert score_to_label(0.10) == "Cold"


def test_score_to_label_warm():
    assert score_to_label(0.45) == "Warm"


def test_score_to_label_hot():
    assert score_to_label(0.85) == "Hot"