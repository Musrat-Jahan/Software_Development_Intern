import os
import joblib
import pandas as pd

MODEL_PATH = "models/lead_model.pkl"


def load_lead_model():
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Lead model file not found: {MODEL_PATH}")
    return joblib.load(MODEL_PATH)


def predict_lead(model_payload, input_data: dict):
    model = model_payload["model"]
    feature_names = model_payload["feature_names"]

    df = pd.DataFrame([input_data])

    # Make sure all required columns exist
    for col in feature_names:
        if col not in df.columns:
            df[col] = 0

    # Keep only training columns and same order
    df = df[feature_names]

    prediction = model.predict(df)[0]

    if hasattr(model, "predict_proba"):
        probability = float(model.predict_proba(df)[0][1])
    else:
        probability = None

    return {
        "prediction": int(prediction),
        "conversion_probability": probability
    }