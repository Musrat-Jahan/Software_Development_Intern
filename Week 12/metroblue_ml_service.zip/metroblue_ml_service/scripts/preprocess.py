import os
import pandas as pd

RAW_DATA_PATH = "data/leads.csv"
PROCESSED_DATA_PATH = "data/processed_leads.csv"


def preprocess_leads():
    if not os.path.exists(RAW_DATA_PATH):
        raise FileNotFoundError(f"Raw leads file not found: {RAW_DATA_PATH}")

    df = pd.read_csv(RAW_DATA_PATH)

    # Standardise column names
    df.columns = [col.strip().lower() for col in df.columns]

    # Create target column
    if "stage" not in df.columns:
        raise ValueError("Column 'stage' not found in raw leads file.")

    df["converted"] = df["stage"].astype(str).str.strip().str.lower().apply(
        lambda x: 1 if x == "paid" else 0
    )

    # Basic feature engineering
    if "source" in df.columns:
        df["source"] = df["source"].fillna("unknown")
    else:
        df["source"] = "unknown"

    if "course_service" in df.columns:
        df["course_service"] = df["course_service"].fillna("unknown")
    else:
        df["course_service"] = "unknown"

    if "gender" in df.columns:
        df["gender"] = df["gender"].fillna("unknown")
    else:
        df["gender"] = "unknown"

    if "location" in df.columns:
        df["has_location"] = df["location"].notna().astype(int)
        df["location"] = df["location"].fillna("unknown")
    else:
        df["has_location"] = 0
        df["location"] = "unknown"

    if "phone" in df.columns:
        df["has_phone"] = df["phone"].notna().astype(int)
    else:
        df["has_phone"] = 0

    if "email" in df.columns:
        df["has_email"] = df["email"].notna().astype(int)
    else:
        df["has_email"] = 0

    # Keep useful columns
    selected_cols = [
        "source",
        "course_service",
        "gender",
        "location",
        "has_location",
        "has_phone",
        "has_email",
        "converted"
    ]

    df = df[selected_cols]

    # One-hot encode text columns
    categorical_cols = ["source", "course_service", "gender", "location"]
    df = pd.get_dummies(df, columns=categorical_cols, drop_first=False)

    os.makedirs("data", exist_ok=True)
    df.to_csv(PROCESSED_DATA_PATH, index=False)

    print(f"Processed file saved to: {PROCESSED_DATA_PATH}")
    print(f"Shape: {df.shape}")


if __name__ == "__main__":
    preprocess_leads()