import os
import json
import joblib
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict, GridSearchCV
from sklearn.metrics import (
accuracy_score,
precision_score,
recall_score,
f1_score,
confusion_matrix,
classification_report
)


DATA_PATH = "data/processed_leads.csv"
MODEL_DIR = "models"
MODEL_PATH = os.path.join(MODEL_DIR, "lead_model.pkl")
RESULTS_PATH = os.path.join(MODEL_DIR, "lead_model_results.json")
FEATURE_IMPORTANCE_PATH = os.path.join(MODEL_DIR, "feature_importance.png")


def load_data():
if not os.path.exists(DATA_PATH):
raise FileNotFoundError(f"Processed data file not found: {DATA_PATH}")

df = pd.read_csv(DATA_PATH)

if "converted" not in df.columns:
raise ValueError("Target column 'converted' not found in processed_leads.csv")

X = df.drop(columns=["converted"])
y = df["converted"]

return X, y


def evaluate_model(name, model, X, y, cv):

if isinstance(cv, int):
# fallback: train and predict on same data
model.fit(X, y)
y_pred = model.predict(X)
else:
y_pred = cross_val_predict(model, X, y, cv=cv)

results = {
"model_name": name,
"accuracy": round(accuracy_score(y, y_pred), 4),
"precision": round(precision_score(y, y_pred, zero_division=0), 4),
"recall": round(recall_score(y, y_pred, zero_division=0), 4),
"f1_score": round(f1_score(y, y_pred, zero_division=0), 4),
"confusion_matrix": confusion_matrix(y, y_pred).tolist(),
"classification_report": classification_report(y, y_pred, zero_division=0, output_dict=True)
}

print("\n" + "=" * 60)
print(f"Model: {name}")
print("=" * 60)
print(f"Accuracy : {results['accuracy']}")
print(f"Precision: {results['precision']}")
print(f"Recall   : {results['recall']}")
print(f"F1 Score : {results['f1_score']}")
print("Confusion Matrix:")
print(confusion_matrix(y, y_pred))
print("\nClassification Report:")
print(classification_report(y, y_pred, zero_division=0))

return results


def train_baseline(X, y, cv):
model = DummyClassifier(strategy="most_frequent")
results = evaluate_model("Baseline", model, X, y, cv)
return model, results


def train_logistic_regression(X, y, cv):
model = LogisticRegression(
max_iter=1000,
class_weight="balanced",
random_state=42
)
results = evaluate_model("Logistic Regression", model, X, y, cv)
return model, results


def train_random_forest(X, y, cv):
rf = RandomForestClassifier(
random_state=42,
class_weight="balanced"
)

param_grid = {
"n_estimators": [100, 200],
"max_depth": [5, 10, None]
}

grid = GridSearchCV(
estimator=rf,
param_grid=param_grid,
scoring="f1",
cv=cv,
n_jobs=-1
)

grid.fit(X, y)

best_model = grid.best_estimator_

print("\nBest Random Forest Parameters:")
print(grid.best_params_)

results = evaluate_model("Random Forest", best_model, X, y, cv)
results["best_params"] = grid.best_params_

return best_model, results


def save_model(model, feature_names):
os.makedirs(MODEL_DIR, exist_ok=True)

payload = {
"model": model,
"feature_names": feature_names
}

joblib.dump(payload, MODEL_PATH)
print(f"\nBest model saved to: {MODEL_PATH}")


def save_results(all_results):
with open(RESULTS_PATH, "w", encoding="utf-8") as f:
json.dump(all_results, f, indent=4)

print(f"Results saved to: {RESULTS_PATH}")


def plot_feature_importance(model, feature_names, top_n=10):
if not hasattr(model, "feature_importances_"):
print("This model does not support feature importance.")
return

importances = model.feature_importances_

importance_df = pd.DataFrame({
"feature": feature_names,
"importance": importances
}).sort_values(by="importance", ascending=False).head(top_n)

plt.figure(figsize=(10, 6))
plt.barh(importance_df["feature"], importance_df["importance"])
plt.gca().invert_yaxis()
plt.xlabel("Importance")
plt.title("Top Feature Importances - Random Forest")
plt.tight_layout()
plt.savefig(FEATURE_IMPORTANCE_PATH)
plt.show()

print(f"Feature importance chart saved to: {FEATURE_IMPORTANCE_PATH}")


def main():
X, y = load_data()

class_counts = y.value_counts()
min_class_size = class_counts.min()

print("Class distribution:")
print(class_counts)

if min_class_size < 2:
print("\nVery small dataset detected → using fallback training (no CV)\n")
cv = 2
else:
n_splits = min(5, min_class_size)
cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
print(f"\nUsing StratifiedKFold with n_splits={n_splits}\n")

# 1. Baseline
_, baseline_results = train_baseline(X, y, cv)
all_results["baseline"] = baseline_results

# 2. Logistic Regression
_, logistic_results = train_logistic_regression(X, y, cv)
all_results["logistic_regression"] = logistic_results

# 3. Random Forest
best_model, rf_results = train_random_forest(X, y, cv)
all_results["random_forest"] = rf_results

# Fit best model on full dataset
best_model.fit(X, y)

# Save best model
save_model(best_model, X.columns.tolist())

# Save results
save_results(all_results)

# Plot feature importance
plot_feature_importance(best_model, X.columns.tolist(), top_n=10)


if __name__ == "__main__":
main()