import subprocess
import sys


def run_step(step_name, command):
    print(f"\nRunning: {step_name}")
    print("-" * 50)

    result = subprocess.run(command, shell=True)

    if result.returncode != 0:
        raise RuntimeError(f"{step_name} failed with exit code {result.returncode}")


def main():
    run_step("Preprocessing leads", "python scripts/preprocess.py")
    run_step("Training lead model", "python scripts/train_lead_model.py")
    print("\nAll steps completed successfully.")


if __name__ == "__main__":
    main()