from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser

#Customize the admin panel for CustomUser
class CustomUserAdmin(UserAdmin):
    # Fields to display in admin list view
    list_display = ('username', 'email', 'first_name', 'last_name', 'phone', 'date_of_birth', 'is_staff')

#Fields to filter by in admin
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'groups')

#Fields to use in the edit form
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'email', 'phone', 'date_of_birth')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )

    # Fields to show when creating a new user
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'first_name', 'last_name', 'phone', 'date_of_birth', 'password1', 'password2'),
        }),
    )

    search_fields = ('username', 'email', 'first_name', 'last_name', 'phone')
    ordering = ('email',)
    filter_horizontal = ('groups', 'user_permissions',)

#Register CustomUser with the customized admin
admin.site.register(CustomUser, CustomUserAdmin)