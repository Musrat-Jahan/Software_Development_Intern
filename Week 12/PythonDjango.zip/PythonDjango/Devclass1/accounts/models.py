from django.db import models
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):
    phone = models.CharField(max_length=20)
    date_of_birth = models.DateField(null=True, blank=True)

    def str(self):
        return self.email