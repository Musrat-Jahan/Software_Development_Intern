from __future__ import annotations
import json
from pathlib import Path
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from app.config import settings
from app.lead_scoring.data import fetch_leads_dataframe
from app.lead_scoring.features import build_training_matrix, LeadFeatureArtifacts

MODEL_PATH = settings.model_dir / "lead_model.joblib"


def evaluate_model(name, model, X, y):
    cv_splits = min(5, max(2, int(y.value_counts().min()))) if y.nunique() > 1 else 2
    cv = StratifiedKFold(n_splits=cv_splits, shuffle=True, random_state=42)
    y_pred = cross_val_predict(model, X, y, cv=cv)
    return {
        "model_name": name,
        "accuracy": round(float(accuracy_score(y, y_pred)), 4),
        "precision": round(float(precision_score(y, y_pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y, y_pred, zero_division=0)), 4),
        "f1": round(float(f1_score(y, y_pred, zero_division=0)), 4),
        "confusion_matrix": confusion_matrix(y, y_pred).tolist(),
    }


def train_best_model() -> dict:
    df = fetch_leads_dataframe()
    X, y, artifacts = build_training_matrix(df)

    lr = LogisticRegression(max_iter=1000, class_weight="balanced")
    rf = RandomForestClassifier(
        n_estimators=300,
        max_depth=10,
        min_samples_split=2,
        min_samples_leaf=1,
        class_weight="balanced",
        random_state=42,
    )

    lr_metrics = evaluate_model("logistic_regression", lr, X, y)
    rf_metrics = evaluate_model("random_forest", rf, X, y)

    best_name = "random_forest" if rf_metrics["f1"] >= lr_metrics["f1"] else "logistic_regression"
    best_model = rf if best_name == "random_forest" else lr
    best_metrics = rf_metrics if best_name == "random_forest" else lr_metrics

    best_model.fit(X, y)

    importances = {}
    if hasattr(best_model, "feature_importances_"):
        importances = {k: float(v) for k, v in zip(X.columns, best_model.feature_importances_)}
    elif hasattr(best_model, "coef_"):
        importances = {k: float(abs(v)) for k, v in zip(X.columns, best_model.coef_[0])}

    payload = {
        "model": best_model,
        "feature_columns": artifacts.feature_columns,
        "top_locations": artifacts.top_locations,
        "feature_importances": dict(sorted(importances.items(), key=lambda kv: kv[1], reverse=True)[:15]),
        "metrics": {"logistic_regression": lr_metrics, "random_forest": rf_metrics, "best": best_metrics},
        "model_name": best_name,
        "training_rows": int(len(df)),
    }
    joblib.dump(payload, MODEL_PATH)
    return payload


if __name__ == "__main__":
    result = train_best_model()
    print(json.dumps({
        "saved_to": str(MODEL_PATH),
        "model_name": result["model_name"],
        "metrics": result["metrics"],
        "training_rows": result["training_rows"],
    }, indent=2))
