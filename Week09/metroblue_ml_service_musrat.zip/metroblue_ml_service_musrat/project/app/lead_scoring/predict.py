from __future__ import annotations
from typing import Any
import joblib
import pandas as pd
from app.config import settings
from app.lead_scoring.features import add_engineered_features
from app.lead_scoring.train import train_best_model, MODEL_PATH


def load_artifacts() -> dict[str, Any]:
    if not MODEL_PATH.exists():
        train_best_model()
    return joblib.load(MODEL_PATH)


def _explain_factors(lead: dict[str, Any]) -> list[str]:
    factors = []
    if lead.get("source"):
        factors.append(f"Source: {lead['source']}")
    if lead.get("course_service"):
        factors.append(f"Service: {lead['course_service']}")
    if lead.get("location"):
        factors.append(f"Location: {lead['location']}")
    if lead.get("referral_id"):
        factors.append("Has referral")
    if lead.get("phone"):
        factors.append("Phone provided")
    notes = str(lead.get("notes") or "")
    if len(notes) >= 10:
        factors.append("Detailed notes present")
    return factors[:5] or ["Limited detail provided"]


def score_lead(lead_dict: dict[str, Any]) -> dict[str, Any]:
    artifacts = load_artifacts()
    model = artifacts["model"]
    feature_columns = artifacts["feature_columns"]
    top_locations = artifacts["top_locations"]

    df = pd.DataFrame([lead_dict])
    X = add_engineered_features(df, top_locations=top_locations)
    X = X.reindex(columns=feature_columns, fill_value=0)

    if hasattr(model, "predict_proba"):
        prob = float(model.predict_proba(X)[0][1])
    else:
        prob = float(model.predict(X)[0])

    label = "Likely to convert" if prob >= 0.60 else "Needs follow-up"
    return {
        "score": round(prob, 4),
        "label": label,
        "factors": _explain_factors(lead_dict),
        "top_probability_class": "Paid" if prob >= 0.50 else "Not Paid",
        "raw": {"model_name": artifacts.get("model_name")},
    }
