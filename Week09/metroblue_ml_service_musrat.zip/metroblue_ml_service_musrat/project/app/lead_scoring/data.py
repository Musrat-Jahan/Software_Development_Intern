from __future__ import annotations
import pandas as pd
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from app.db import get_engine


LEAD_QUERY = """
SELECT
    l.id,
    l.name,
    l.source,
    l.course_service,
    l.gender,
    l.location,
    l.phone,
    l.stage,
    l.contacted_at,
    l.created_at,
    l.referral_id,
    l.notes,
    r.user_id AS referral_user_id,
    r.name AS referral_name,
    r.phone AS referral_phone,
    r.email AS referral_email,
    c.id AS client_id,
    c.name AS client_name,
    c.location AS client_location
FROM leads l
LEFT JOIN referrals r ON l.referral_id = r.id
LEFT JOIN clients c ON c.lead_id = l.id
"""


def sample_leads_df() -> pd.DataFrame:
    now = pd.Timestamp.now().normalize()
    rows = [
        {"id": 1, "name": "A", "source": "Facebook", "course_service": "IELTS", "gender": "Male", "location": "Darwin", "phone": "0400", "stage": "Paid", "contacted_at": now - pd.Timedelta(days=20), "created_at": now - pd.Timedelta(days=22), "referral_id": 1, "notes": "Very interested", "client_id": 10},
        {"id": 2, "name": "B", "source": "Walk-in", "course_service": "PTE", "gender": "Female", "location": "Palmerston", "phone": None, "stage": "Cold", "contacted_at": None, "created_at": now - pd.Timedelta(days=3), "referral_id": None, "notes": None, "client_id": None},
        {"id": 3, "name": "C", "source": "Google", "course_service": "Migration", "gender": None, "location": "Darwin", "phone": "0401", "stage": "Hot", "contacted_at": now - pd.Timedelta(days=5), "created_at": now - pd.Timedelta(days=8), "referral_id": 1, "notes": "Needs callback", "client_id": None},
        {"id": 4, "name": "D", "source": "Facebook", "course_service": "IELTS", "gender": "Female", "location": None, "phone": "0402", "stage": "Paid", "contacted_at": now - pd.Timedelta(days=10), "created_at": now - pd.Timedelta(days=12), "referral_id": 2, "notes": "Paid quickly", "client_id": 11},
        {"id": 5, "name": "E", "source": "Referral", "course_service": "Student Visa", "gender": "Male", "location": "Katherine", "phone": "0403", "stage": "Warm", "contacted_at": now - pd.Timedelta(days=15), "created_at": now - pd.Timedelta(days=18), "referral_id": 2, "notes": "Follow up next week", "client_id": None},
        {"id": 6, "name": "F", "source": "Google", "course_service": "PTE", "gender": "Female", "location": "Darwin", "phone": None, "stage": "Cold", "contacted_at": None, "created_at": now - pd.Timedelta(days=1), "referral_id": None, "notes": "", "client_id": None},
    ]
    return pd.DataFrame(rows)


def fetch_leads_dataframe() -> pd.DataFrame:
    try:
        engine = get_engine()
        with engine.connect() as conn:
            df = pd.read_sql(text(LEAD_QUERY), conn)
        if df.empty:
            return sample_leads_df()
        return df
    except SQLAlchemyError:
        return sample_leads_df()
